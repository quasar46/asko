$(document).ready(function () {
  $(".slider1").owlCarousel({
    items: 1,
    nav: true,
    navText: ["", ""],
    dots: false
  });
});

$(document).ready(function () {
  $(".slider2").owlCarousel({
    items: 4,
    nav: true,
    navText: ["", ""],
    dots: false,
    margin: 25
  });
});